import { useEffect, useState } from 'react';

export type ToastVariant = 'default' | 'destructive';

export interface ToastOptions {
  title?: string;
  description?: string;
  variant?: ToastVariant;
  duration?: number;
}

export interface ToastItem extends ToastOptions {
  id: string;
}

type Listener = (toasts: ToastItem[]) => void;

// External store — lets `toast()` be called from anywhere,
// while useToast() re-renders any subscribed component (Toaster)
let toasts: ToastItem[] = [];
const listeners = new Set<Listener>();

function emit() {
  listeners.forEach((listener) => listener(toasts));
}

function dismiss(id: string) {
  toasts = toasts.filter((t) => t.id !== id);
  emit();
}

function toast(options: ToastOptions) {
  const id = crypto.randomUUID();
  const duration = options.duration ?? 4000;

  toasts = [...toasts, { id, variant: 'default', ...options }];
  emit();

  if (duration > 0) {
    setTimeout(() => dismiss(id), duration);
  }

  return { id, dismiss: () => dismiss(id) };
}

export function useToast() {
  const [state, setState] = useState<ToastItem[]>(toasts);

  useEffect(() => {
    listeners.add(setState);
    return () => {
      listeners.delete(setState);
    };
  }, []);

  return { toast, toasts: state, dismiss };
}