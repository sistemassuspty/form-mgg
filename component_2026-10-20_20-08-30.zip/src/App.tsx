import { Route, Routes } from 'react-router-dom';

import { SiteHeader } from '@/components/SiteHeader';
import { AdminPage } from '@/pages/AdminPage';
import { PreApprovalPage } from '@/pages/PreApprovalPage';

function App() {
  return (
    <div className="min-h-screen bg-muted/40 font-sans">
      <SiteHeader />
      <Routes>
        <Route path="/" element={<PreApprovalPage />} />
        <Route path="/admin" element={<AdminPage />} />
        <Route path="*" element={<PreApprovalPage />} />
      </Routes>
    </div>
  );
}

export default App;
