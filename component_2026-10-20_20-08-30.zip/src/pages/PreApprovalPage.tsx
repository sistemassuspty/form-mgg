import { JetRequestError } from '@jet-admin/jet-sdk';
import { ArrowLeft, ArrowRight, CheckCircle2, Loader2 } from 'lucide-react';
import { useState } from 'react';

import { AddressGroupField } from '@/components/AddressGroupField';
import { FieldInput } from '@/components/FieldInput';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import {
  EMPTY_VALUES,
  STEPS,
  isGroup,
  validateStep,
  type FieldKey,
  type FormValues,
} from '@/lib/applicationSchema';
import { jet } from '@/lib/jet';

const SUBMIT_WORKFLOW_ID = '0616530a-6174-4026-a4fa-ef3f36c515f1';

const getErrorMessage = (error: unknown): string => {
  if (error instanceof JetRequestError) {
    return error.nonFieldErrors[0] ?? 'No pudimos enviar tu solicitud. Intenta de nuevo.';
  }
  return 'No pudimos enviar tu solicitud. Intenta de nuevo.';
};

export function PreApprovalPage() {
  const [stepIndex, setStepIndex] = useState(0);
  const [values, setValues] = useState<FormValues>(EMPTY_VALUES);
  const [errors, setErrors] = useState<Partial<Record<FieldKey, string>>>({});
  const [submitting, setSubmitting] = useState(false);
  const [submitError, setSubmitError] = useState<string | null>(null);
  const [submitted, setSubmitted] = useState(false);

  const step = STEPS[stepIndex];
  const isLastStep = stepIndex === STEPS.length - 1;
  const progress = ((stepIndex + 1) / STEPS.length) * 100;

  const updateValue = (key: FieldKey, value: string): void => {
    setValues((current) => ({ ...current, [key]: value }));
    setErrors((current) => ({ ...current, [key]: undefined }));
  };

  const submit = async (): Promise<void> => {
    setSubmitting(true);
    setSubmitError(null);
    try {
      const response = await jet.workflow(SUBMIT_WORKFLOW_ID).execute({ data: { ...values } });
      const result = response.result as { result?: boolean; error?: string } | undefined;
      if (!response.success || result?.result === false) {
        setSubmitError(result?.error ?? 'No pudimos enviar tu solicitud. Intenta de nuevo.');
        return;
      }
      setSubmitted(true);
    } catch (error) {
      setSubmitError(getErrorMessage(error));
    } finally {
      setSubmitting(false);
    }
  };

  const handleNext = (): void => {
    if (!step) return;
    const stepErrors = validateStep(step, values);
    setErrors(stepErrors);
    if (Object.keys(stepErrors).length > 0) return;
    if (isLastStep) {
      void submit();
      return;
    }
    setStepIndex((current) => current + 1);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const reset = (): void => {
    setValues(EMPTY_VALUES);
    setErrors({});
    setStepIndex(0);
    setSubmitted(false);
  };

  if (submitted) {
    return (
      <main className="mx-auto max-w-2xl px-4 py-10 sm:py-16">
        <Card className="rounded-2xl border p-8 text-center shadow-sm sm:p-12">
          <CheckCircle2 className="mx-auto h-14 w-14 text-primary" strokeWidth={1.25} />
          <h1 className="mt-6 text-2xl font-semibold">¡Solicitud enviada!</h1>
          <p className="mt-3 text-muted-foreground">
            Gracias, {values.full_name.split(' ')[0]}. Revisaremos tu información y nos pondremos
            en contacto contigo al correo {values.email}.
          </p>
          <Button className="mt-8 rounded-lg" variant="outline" onClick={reset}>
            Enviar otra solicitud
          </Button>
        </Card>
      </main>
    );
  }

  if (!step) return null;

  return (
    <main className="mx-auto max-w-2xl px-4 py-8 sm:py-12">
      <div className="mb-8 space-y-2 text-center">
        <h1 className="text-2xl font-semibold tracking-tight sm:text-3xl">
          Formulario de Pre-Aprobación de Vehículo
        </h1>
        <p className="text-muted-foreground">
          Completa la solicitud en unos minutos y conoce si calificas para nuestro servicio.
        </p>
      </div>

      <div className="mb-4 space-y-2">
        <div className="flex items-center justify-between text-xs text-muted-foreground">
          <span>
            Paso {stepIndex + 1} de {STEPS.length}
          </span>
          <span>{step.title}</span>
        </div>
        <Progress value={progress} className="h-1.5" />
      </div>

      <Card className="rounded-2xl border p-5 shadow-sm transition-all duration-200 sm:p-8">
        <h2 className="text-lg font-semibold">{step.title}</h2>
        <p className="mb-6 text-sm text-muted-foreground">{step.description}</p>

        <div className="grid grid-cols-1 gap-5 sm:grid-cols-2">
          {step.fields.map((item) =>
            isGroup(item) ? (
              <AddressGroupField
                key={item.label}
                group={item}
                values={values}
                errors={errors}
                onChange={updateValue}
              />
            ) : (
              <FieldInput
                key={item.key}
                field={item}
                value={values[item.key]}
                error={errors[item.key]}
                onChange={(value) => updateValue(item.key, value)}
              />
            ),
          )}
        </div>

        {submitError && (
          <p className="mt-5 rounded-lg bg-destructive/10 px-3 py-2 text-sm text-destructive">
            {submitError}
          </p>
        )}

        <div className="mt-8 flex items-center justify-between gap-3">
          <Button
            type="button"
            variant="ghost"
            className="rounded-lg"
            disabled={stepIndex === 0 || submitting}
            onClick={() => setStepIndex((current) => Math.max(0, current - 1))}
          >
            <ArrowLeft className="mr-2 h-4 w-4" strokeWidth={1.5} />
            Atrás
          </Button>
          <Button type="button" className="rounded-lg" disabled={submitting} onClick={handleNext}>
            {submitting && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
            {isLastStep ? 'Enviar solicitud' : 'Continuar'}
            {!isLastStep && <ArrowRight className="ml-2 h-4 w-4" strokeWidth={1.5} />}
          </Button>
        </div>
      </Card>
    </main>
  );
}
