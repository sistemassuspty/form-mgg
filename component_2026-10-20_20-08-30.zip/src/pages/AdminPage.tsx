import { JetRequestError } from '@jet-admin/jet-sdk';
import { format } from 'date-fns';
import { es } from 'date-fns/locale';
import { Loader2, LogOut } from 'lucide-react';
import { useCallback, useEffect, useState } from 'react';

import { ApplicationDialog } from '@/components/ApplicationDialog';
import { LoginCard } from '@/components/LoginCard';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  STATUS_OPTIONS,
  formatMoney,
  toApplication,
  type Application,
} from '@/lib/applications';
import { jet } from '@/lib/jet';

const applicationsCollection = jet.collection('jet_database', 'preapproval_applications');

type AuthState = 'loading' | 'anonymous' | 'authenticated';

export function AdminPage() {
  const [authState, setAuthState] = useState<AuthState>('loading');
  const [applications, setApplications] = useState<Application[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [selected, setSelected] = useState<Application | null>(null);

  const loadApplications = useCallback(async (): Promise<void> => {
    setLoading(true);
    setError(null);
    try {
      const response = await applicationsCollection.list({
        pagination: { page: 1, perPage: 200 },
        orderBy: { field: 'created_at', desc: true },
      });
      setApplications(response.results.map(toApplication));
    } catch (caught) {
      setError(
        caught instanceof JetRequestError
          ? (caught.nonFieldErrors[0] ?? 'No se pudieron cargar las solicitudes.')
          : 'No se pudieron cargar las solicitudes.',
      );
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void jet.auth.isAuthenticated().then((response) => {
      setAuthState(response.authenticated ? 'authenticated' : 'anonymous');
    });
  }, []);

  useEffect(() => {
    if (authState === 'authenticated') void loadApplications();
  }, [authState, loadApplications]);

  const updateStatus = async (application: Application, status: string): Promise<void> => {
    setApplications((current) =>
      current.map((item) => (item.id === application.id ? { ...item, status } : item)),
    );
    try {
      await applicationsCollection.update({
        primaryKey: String(application.id),
        data: { status },
      });
    } catch {
      setError('No se pudo actualizar el estado.');
      void loadApplications();
    }
  };

  const logout = async (): Promise<void> => {
    await jet.auth.logout();
    setApplications([]);
    setAuthState('anonymous');
  };

  if (authState === 'loading') {
    return (
      <div className="flex justify-center py-24">
        <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
      </div>
    );
  }

  if (authState === 'anonymous') {
    return <LoginCard onLoggedIn={() => setAuthState('authenticated')} />;
  }

  return (
    <main className="mx-auto max-w-5xl px-4 py-8">
      <div className="mb-6 flex items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight">Solicitudes recibidas</h1>
          <p className="text-sm text-muted-foreground">{applications.length} en total</p>
        </div>
        <Button variant="outline" className="rounded-lg" onClick={() => void logout()}>
          <LogOut className="mr-2 h-4 w-4" strokeWidth={1.5} />
          Salir
        </Button>
      </div>

      {error && (
        <p className="mb-4 rounded-lg bg-destructive/10 px-3 py-2 text-sm text-destructive">{error}</p>
      )}

      <Card className="overflow-hidden rounded-2xl border shadow-sm">
        {loading && (
          <div className="flex justify-center py-12">
            <Loader2 className="h-5 w-5 animate-spin text-muted-foreground" />
          </div>
        )}
        {!loading && applications.length === 0 && (
          <p className="py-12 text-center text-sm text-muted-foreground">
            Aún no hay solicitudes.
          </p>
        )}
        {!loading && applications.length > 0 && (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm">
              <thead className="border-b bg-muted/50 text-xs uppercase text-muted-foreground">
                <tr>
                  <th className="px-4 py-3 font-medium">Solicitante</th>
                  <th className="hidden px-4 py-3 font-medium md:table-cell">Vehículo</th>
                  <th className="hidden px-4 py-3 font-medium lg:table-cell">Fecha</th>
                  <th className="px-4 py-3 font-medium">Estado</th>
                </tr>
              </thead>
              <tbody className="divide-y">
                {applications.map((application) => (
                  <tr
                    key={application.id}
                    className="cursor-pointer transition-colors duration-150 hover:bg-muted/40"
                    onClick={() => setSelected(application)}
                  >
                    <td className="px-4 py-3">
                      <div className="font-medium">{application.fullName}</div>
                      <div className="text-xs text-muted-foreground">{application.email}</div>
                    </td>
                    <td className="hidden px-4 py-3 md:table-cell">
                      {`${application.vehicleBrand} ${application.vehicleModel}`.trim() || '—'}
                    </td>
                    <td className="hidden px-4 py-3 lg:table-cell">
                      {application.createdAt
                        ? format(new Date(application.createdAt), 'dd MMM yyyy', { locale: es })
                        : '—'}
                    </td>
                    <td className="px-4 py-3" onClick={(event) => event.stopPropagation()}>
                      <Select
                        value={application.status}
                        onValueChange={(value) => void updateStatus(application, value)}
                      >
                        <SelectTrigger className="h-9 w-36 rounded-lg">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {STATUS_OPTIONS.map((option) => (
                            <SelectItem key={option.value} value={option.value}>
                              {option.label}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Card>

      <ApplicationDialog application={selected} onClose={() => setSelected(null)} />
    </main>
  );
}
