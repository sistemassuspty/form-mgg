import { Jet } from '@jet-admin/jet-sdk';

export const jet = new Jet({
  env: import.meta.env,
});
