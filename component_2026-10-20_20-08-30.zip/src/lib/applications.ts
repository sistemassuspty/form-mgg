import type { CollectionRecord } from '@jet-admin/jet-sdk';

export interface Application {
  id: number;
  fullName: string;
  email: string;
  phone: string;
  birthDate: string | null;
  idNumber: string;
  address: string;
  addressLine2: string;
  neighborhood: string;
  province: string;
  district: string;
  corregimiento: string;
  city: string;
  employmentStatus: string;
  employer: string;
  monthlyIncome: number | null;
  vehicleBrand: string;
  vehicleModel: string;
  status: string;
  createdAt: string | null;
}

export const STATUS_OPTIONS = [
  { value: 'new', label: 'Nueva' },
  { value: 'in_review', label: 'En revisión' },
  { value: 'approved', label: 'Pre-aprobada' },
  { value: 'rejected', label: 'Rechazada' },
];

const text = (value: unknown): string => (value === null || value === undefined ? '' : String(value));

const numberOrNull = (value: unknown): number | null => {
  if (value === null || value === undefined || value === '') return null;
  const parsed = Number(value);
  return Number.isNaN(parsed) ? null : parsed;
};

const dateOrNull = (value: unknown): string | null => (value ? String(value) : null);

export const toApplication = (record: CollectionRecord): Application => {
  const { data } = record;
  return {
    id: Number(data.id),
    fullName: text(data.full_name),
    email: text(data.email),
    phone: text(data.phone),
    birthDate: dateOrNull(data.birth_date),
    idNumber: text(data.id_number),
    address: text(data.address),
    addressLine2: text(data.address_line2),
    neighborhood: text(data.neighborhood),
    province: text(data.province),
    district: text(data.district),
    corregimiento: text(data.corregimiento),
    city: text(data.city),
    employmentStatus: text(data.employment_status),
    employer: text(data.employer),
    monthlyIncome: numberOrNull(data.monthly_income),
    vehicleBrand: text(data.vehicle_brand),
    vehicleModel: text(data.vehicle_model),
    status: text(data.status) || 'new',
    createdAt: dateOrNull(data.created_at),
  };
};

export const formatMoney = (value: number | null): string =>
  value === null
    ? '—'
    : new Intl.NumberFormat('es', { style: 'currency', currency: 'USD', maximumFractionDigits: 0 }).format(
        value,
      );

export const formatAddress = (application: Application): string =>
  [
    application.address,
    application.addressLine2,
    application.neighborhood || application.city,
    application.corregimiento,
    application.district,
    application.province,
  ]
    .filter(Boolean)
    .join(', ') || '—';
