export type FieldKey =
  | 'full_name'
  | 'email'
  | 'phone'
  | 'birth_date'
  | 'id_number'
  | 'address'
  | 'address_line2'
  | 'neighborhood'
  | 'province'
  | 'district'
  | 'corregimiento'
  | 'employment_status'
  | 'employer'
  | 'monthly_income'
  | 'vehicle_brand'
  | 'vehicle_model';

export type FormValues = Record<FieldKey, string>;

export type FieldType = 'text' | 'email' | 'tel' | 'number' | 'date' | 'select' | 'textarea';

export interface FieldOption {
  value: string;
  label: string;
}

export interface FieldConfig {
  key: FieldKey;
  label: string;
  type: FieldType;
  required: boolean;
  placeholder?: string;
  options?: FieldOption[];
  span?: 'full';
}

export interface GroupPart {
  key: FieldKey;
  sublabel: string;
  required: boolean;
}

export interface GroupConfig {
  label: string;
  required: boolean;
  parts: GroupPart[];
}

export type StepItem = FieldConfig | GroupConfig;

export interface StepConfig {
  title: string;
  description: string;
  fields: StepItem[];
}

export const isGroup = (item: StepItem): item is GroupConfig => 'parts' in item;

const toOptions = (values: string[]): FieldOption[] =>
  values.map((value) => ({ value, label: value }));

export const EMPLOYMENT_OPTIONS = toOptions([
  'Empleado',
  'Independiente',
  'Empresario',
  'Jubilado',
  'Otro',
]);

export const PROVINCE_OPTIONS = toOptions(['PANAMÁ', 'PANAMÁ OESTE', 'PANAMÁ ESTE']);

export const DISTRICT_OPTIONS = toOptions([
  'San Miguelito',
  'Balboa',
  'Chepo',
  'Chimán',
  'Panamá',
  'Taboga',
]);

export const CORREGIMIENTO_OPTIONS = toOptions([
  '24 de Diciembre',
  'Alcalde Díaz',
  'Amelia Denis de Icaza',
  'Ancón',
  'Arnulfo Arias',
  'Belisario Frías',
  'Belisario Porras',
  'Brujas',
  'Caimitillo',
  'Cañita',
  'Chepillo',
  'Chepo (Cabecera)',
  'Chilibre',
  'Chimán (Cabecera)',
  'Comarca Kuna de Madungandí',
  'Curundú',
  'El Llano',
  'Ernesto Córdoba Campos',
  'Gonzalo Vásquez',
  'Juan Díaz',
  'La Esmeralda',
  'La Guinea',
  'Las Garzas',
  'Las Mañanitas',
  'Las Margaritas',
  'Mateo Iturralde (Cabecera)',
  'Omar Torrijos',
  'Otoque Occidente',
  'Pásiga',
  'Pedregal',
  'Pedro González',
  'San Martín',
  'San Miguel (Cabecera)',
  'Santa Cruz de Chinina',
  'Tocumen',
  'Tortí',
  'Unión Santeña',
  'Victoriano Lorenzo',
]);

export const STEPS: StepConfig[] = [
  {
    title: 'Datos personales',
    description: 'Cuéntanos quién eres y cómo contactarte.',
    fields: [
      { key: 'full_name', label: 'Nombre completo', type: 'text', required: true, span: 'full' },
      { key: 'email', label: 'Correo electrónico', type: 'email', required: true },
      { key: 'phone', label: 'Teléfono', type: 'tel', required: true },
      { key: 'birth_date', label: 'Fecha de nacimiento', type: 'date', required: true },
      { key: 'id_number', label: 'Número de identificación', type: 'text', required: true },
      {
        label: 'Dirección de residencia del Solicitante',
        required: true,
        parts: [
          { key: 'address', sublabel: 'Avenida / Calle', required: true },
          {
            key: 'address_line2',
            sublabel: 'Casa / Edificio / N° / Apartamento / Piso',
            required: false,
          },
          { key: 'neighborhood', sublabel: 'Urbanización / Barriada', required: true },
        ],
      },
      {
        key: 'province',
        label: 'Provincia',
        type: 'select',
        required: true,
        options: PROVINCE_OPTIONS,
        span: 'full',
      },
      {
        key: 'district',
        label: 'Distrito',
        type: 'select',
        required: true,
        options: DISTRICT_OPTIONS,
        span: 'full',
      },
      {
        key: 'corregimiento',
        label: 'Corregimiento',
        type: 'select',
        required: true,
        options: CORREGIMIENTO_OPTIONS,
        span: 'full',
      },
    ],
  },
  {
    title: 'Empleo e ingresos',
    description: 'Información sobre tu situación laboral.',
    fields: [
      {
        key: 'employment_status',
        label: 'Situación laboral',
        type: 'select',
        required: true,
        options: EMPLOYMENT_OPTIONS,
      },
      { key: 'employer', label: 'Empleador o empresa', type: 'text', required: false },
      {
        key: 'monthly_income',
        label: 'Ingreso mensual',
        type: 'number',
        required: true,
        placeholder: '0',
      },
    ],
  },
  {
    title: 'Vehículo',
    description: 'Describe el vehículo que quieres obtener.',
    fields: [
      { key: 'vehicle_brand', label: 'Marca', type: 'text', required: true },
      { key: 'vehicle_model', label: 'Modelo', type: 'text', required: true },
    ],
  },
];

export const EMPTY_VALUES: FormValues = {
  full_name: '',
  email: '',
  phone: '',
  birth_date: '',
  id_number: '',
  address: '',
  address_line2: '',
  neighborhood: '',
  province: '',
  district: '',
  corregimiento: '',
  employment_status: '',
  employer: '',
  monthly_income: '',
  vehicle_brand: '',
  vehicle_model: '',
};

const EMAIL_REGEX = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

const REQUIRED_MESSAGE = 'Este campo es obligatorio.';

const calculateAge = (isoDate: string): number => {
  const birth = new Date(`${isoDate}T00:00:00`);
  const today = new Date();
  let age = today.getFullYear() - birth.getFullYear();
  const monthDiff = today.getMonth() - birth.getMonth();
  if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birth.getDate())) age -= 1;
  return age;
};

export const validateField = (field: FieldConfig, values: FormValues): string | null => {
  const value = values[field.key].trim();

  if (!value) return field.required ? REQUIRED_MESSAGE : null;
  if (field.type === 'email' && !EMAIL_REGEX.test(value)) return 'Ingresa un correo válido.';
  if (field.type === 'number' && (Number.isNaN(Number(value)) || Number(value) < 0)) {
    return 'Ingresa un número válido.';
  }
  if (field.key === 'birth_date' && calculateAge(value) < 18) {
    return 'Debes ser mayor de 18 años.';
  }
  return null;
};

const validateGroup = (group: GroupConfig, values: FormValues): Partial<Record<FieldKey, string>> =>
  Object.fromEntries(
    group.parts
      .filter((part) => group.required && part.required && !values[part.key].trim())
      .map((part) => [part.key, REQUIRED_MESSAGE]),
  );

export const validateStep = (step: StepConfig, values: FormValues): Partial<Record<FieldKey, string>> =>
  step.fields.reduce<Partial<Record<FieldKey, string>>>((errors, item) => {
    if (isGroup(item)) return { ...errors, ...validateGroup(item, values) };
    const error = validateField(item, values);
    return error ? { ...errors, [item.key]: error } : errors;
  }, {});
