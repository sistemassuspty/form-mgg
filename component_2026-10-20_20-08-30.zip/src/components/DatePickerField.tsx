import { addMonths, format, isSameMonth, parseISO } from 'date-fns';
import { es } from 'date-fns/locale';
import { CalendarIcon, ChevronLeft, ChevronRight } from 'lucide-react';
import { useState } from 'react';

import { Button } from '@/components/ui/button';
import { Calendar } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { cn } from '@/lib/utils';

interface DatePickerFieldProps {
  id: string;
  value: string;
  onChange: (value: string) => void;
  invalid?: boolean;
}

const YEAR_SPAN = 100;

const capitalize = (value: string): string => value.charAt(0).toUpperCase() + value.slice(1);

const MONTH_NAMES = Array.from({ length: 12 }, (_, index) =>
  capitalize(format(new Date(2000, index, 1), 'LLLL', { locale: es })),
);

export function DatePickerField({ id, value, onChange, invalid }: DatePickerFieldProps) {
  const today = new Date();
  const selected = value ? parseISO(value) : undefined;
  const minYear = today.getFullYear() - YEAR_SPAN;
  const [open, setOpen] = useState(false);
  const [month, setMonth] = useState<Date>(selected ?? new Date(today.getFullYear() - 30, 0, 1));

  const years = Array.from({ length: YEAR_SPAN + 1 }, (_, index) =>
    String(today.getFullYear() - index),
  );
  const canGoNext = !isSameMonth(month, today) && month < today;
  const canGoPrevious = month.getFullYear() > minYear || month.getMonth() > 0;

  const handleOpenChange = (nextOpen: boolean): void => {
    if (nextOpen && selected) setMonth(selected);
    setOpen(nextOpen);
  };

  return (
    <Popover open={open} onOpenChange={handleOpenChange}>
      <PopoverTrigger asChild>
        <Button
          id={id}
          type="button"
          variant="outline"
          className={cn(
            'h-11 w-full justify-start rounded-lg px-3 font-normal',
            !selected && 'text-muted-foreground',
            invalid && 'border-destructive',
          )}
        >
          <CalendarIcon className="mr-2 h-4 w-4" strokeWidth={1.5} />
          {selected ? format(selected, 'PPP', { locale: es }) : 'Selecciona una fecha'}
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-auto p-0" align="start">
        <div className="flex items-center gap-2 px-3 pt-3">
          <Button
            type="button"
            variant="outline"
            size="icon"
            className="h-8 w-8 shrink-0"
            disabled={!canGoPrevious}
            onClick={() => setMonth((current) => addMonths(current, -1))}
            aria-label="Mes anterior"
          >
            <ChevronLeft className="h-4 w-4" />
          </Button>
          <Select
            value={String(month.getMonth())}
            onValueChange={(next) =>
              setMonth((current) => new Date(current.getFullYear(), Number(next), 1))
            }
          >
            <SelectTrigger className="h-8 min-w-0 flex-1 px-2 text-sm">
              <SelectValue />
            </SelectTrigger>
            <SelectContent className="max-h-64">
              {MONTH_NAMES.map((name, index) => (
                <SelectItem key={name} value={String(index)}>
                  {name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Select
            value={String(month.getFullYear())}
            onValueChange={(next) =>
              setMonth((current) => new Date(Number(next), current.getMonth(), 1))
            }
          >
            <SelectTrigger className="h-8 w-[88px] shrink-0 px-2 text-sm">
              <SelectValue />
            </SelectTrigger>
            <SelectContent className="max-h-64">
              {years.map((year) => (
                <SelectItem key={year} value={year}>
                  {year}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Button
            type="button"
            variant="outline"
            size="icon"
            className="h-8 w-8 shrink-0"
            disabled={!canGoNext}
            onClick={() => setMonth((current) => addMonths(current, 1))}
            aria-label="Mes siguiente"
          >
            <ChevronRight className="h-4 w-4" />
          </Button>
        </div>
        <Calendar
          mode="single"
          locale={es}
          month={month}
          onMonthChange={setMonth}
          startMonth={new Date(minYear, 0)}
          endMonth={today}
          selected={selected}
          disabled={{ after: today }}
          onSelect={(date) => {
            if (!date) return;
            onChange(format(date, 'yyyy-MM-dd'));
            setOpen(false);
          }}
          classNames={{ month_caption: 'hidden', nav: 'hidden' }}
        />
      </PopoverContent>
    </Popover>
  );
}
