import { format } from 'date-fns';
import { es } from 'date-fns/locale';

import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { formatAddress, formatMoney, type Application } from '@/lib/applications';

interface ApplicationDialogProps {
  application: Application | null;
  onClose: () => void;
}

const formatDate = (value: string | null): string =>
  value ? format(new Date(value), 'PPP', { locale: es }) : '—';

export function ApplicationDialog({ application, onClose }: ApplicationDialogProps) {
  const rows: Array<[string, string]> = application
    ? [
        ['Correo', application.email],
        ['Teléfono', application.phone],
        ['Nacimiento', formatDate(application.birthDate)],
        ['Identificación', application.idNumber || '—'],
        ['Dirección', formatAddress(application)],
        ['Situación laboral', application.employmentStatus || '—'],
        ['Empleador', application.employer || '—'],
        ['Ingreso mensual', formatMoney(application.monthlyIncome)],
        ['Marca', application.vehicleBrand || '—'],
        ['Modelo', application.vehicleModel || '—'],
      ]
    : [];

  return (
    <Dialog open={application !== null} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-lg">
        <DialogHeader>
          <DialogTitle>{application?.fullName}</DialogTitle>
          <DialogDescription>
            Solicitud #{application?.id} · {formatDate(application?.createdAt ?? null)}
          </DialogDescription>
        </DialogHeader>
        <dl className="divide-y text-sm">
          {rows.map(([label, value]) => (
            <div key={label} className="grid grid-cols-3 gap-3 py-2">
              <dt className="text-muted-foreground">{label}</dt>
              <dd className="col-span-2 break-words">{value}</dd>
            </div>
          ))}
        </dl>
      </DialogContent>
    </Dialog>
  );
}
