import { Input } from '@/components/ui/input';
import type { FieldKey, FormValues, GroupConfig } from '@/lib/applicationSchema';
import { cn } from '@/lib/utils';

interface AddressGroupFieldProps {
  group: GroupConfig;
  values: FormValues;
  errors: Partial<Record<FieldKey, string>>;
  onChange: (key: FieldKey, value: string) => void;
}

export function AddressGroupField({ group, values, errors, onChange }: AddressGroupFieldProps) {
  const firstKey = group.parts[0]?.key;

  return (
    <div className="space-y-4 sm:col-span-2">
      <label htmlFor={firstKey ? `field-${firstKey}` : undefined} className="block text-base font-medium">
        {group.label}
        {group.required && <span className="ml-2 text-destructive">*</span>}
      </label>
      {group.parts.map((part) => (
        <div key={part.key} className="space-y-2">
          <Input
            id={`field-${part.key}`}
            value={values[part.key]}
            onChange={(event) => onChange(part.key, event.target.value)}
            className={cn(
              'h-11 rounded-lg',
              errors[part.key] && 'border-destructive focus-visible:ring-destructive',
            )}
          />
          <p className="text-xs uppercase tracking-wide text-muted-foreground">{part.sublabel}</p>
          {errors[part.key] && <p className="text-xs text-destructive">{errors[part.key]}</p>}
        </div>
      ))}
    </div>
  );
}
