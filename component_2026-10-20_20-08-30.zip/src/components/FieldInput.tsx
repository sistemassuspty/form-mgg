import { DatePickerField } from '@/components/DatePickerField';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import type { FieldConfig } from '@/lib/applicationSchema';
import { cn } from '@/lib/utils';

interface FieldInputProps {
  field: FieldConfig;
  value: string;
  error?: string | undefined;
  onChange: (value: string) => void;
}

export function FieldInput({ field, value, error, onChange }: FieldInputProps) {
  const id = `field-${field.key}`;
  const invalidClass = error ? 'border-destructive focus-visible:ring-destructive' : '';

  return (
    <div className={cn('space-y-2', field.span === 'full' && 'sm:col-span-2')}>
      <Label htmlFor={id}>
        {field.label}
        {field.required && <span className="ml-0.5 text-destructive">*</span>}
      </Label>
      {field.type === 'select' && (
        <Select value={value} onValueChange={onChange}>
          <SelectTrigger id={id} className={cn('h-11 rounded-lg', invalidClass)}>
            <SelectValue placeholder="Selecciona una opción" />
          </SelectTrigger>
          <SelectContent className="max-h-72">
            {field.options?.map((option) => (
              <SelectItem key={option.value} value={option.value}>
                {option.label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      )}
      {field.type === 'date' && (
        <DatePickerField id={id} value={value} onChange={onChange} invalid={Boolean(error)} />
      )}
      {field.type === 'textarea' && (
        <Textarea
          id={id}
          rows={4}
          value={value}
          onChange={(event) => onChange(event.target.value)}
          className={cn('rounded-lg', invalidClass)}
        />
      )}
      {(field.type === 'text' ||
        field.type === 'email' ||
        field.type === 'tel' ||
        field.type === 'number') && (
        <Input
          id={id}
          type={field.type}
          inputMode={field.type === 'number' ? 'decimal' : undefined}
          min={field.type === 'number' ? 0 : undefined}
          placeholder={field.placeholder}
          value={value}
          onChange={(event) => onChange(event.target.value)}
          className={cn('h-11 rounded-lg', invalidClass)}
        />
      )}
      {error && <p className="text-xs text-destructive">{error}</p>}
    </div>
  );
}
